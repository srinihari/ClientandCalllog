<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class CalllogtDetails extends Model
{
	use SoftDeletes;
    protected $table='callog_details';

     public function getCallog(){
     	return $list=CalllogtDetails::where('deleted_at')->orderBy('id','desc')->paginate(10);
     }

    public function getClient(){
    	return $this->belongsTo('App\Model\ClientDetails','client_id','id');
    }



}
