<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class ClientDetails extends Model
{
	use SoftDeletes;

    protected $table='client_details';
    
	 public function getClientList(){
     	return $list=ClientDetails::where('deleted_at')->orderBy('id','desc')->paginate(10);
     }   

     public function getCompany(){
     	return $this->belongsTo('\App\Model\CompanyMaster','company_id','id');
     }
}
