<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;


class User extends Authenticatable
{
    use SoftDeletes,Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'mobile_no','password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function getUsers($request){
            $users=$this->where(function($query) use ($request){
                if($request->filled('search')){
                    $query->where('name','like','%'.$request->search.'%')
                    ->orWhere('email','like','%'.$request->search.'%');
                }
            });
            return $users->where('name','!=','admin')->whereNull('deleted_at')->orderBy('id','DESC')->paginate(10);
    }
}
