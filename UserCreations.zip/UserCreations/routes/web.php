<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');



Route::middleware(['auth'])->group(function(){
	Route::get('client-list','ClientManagementController@clientIndex');
	Route::get('client-edit/{id}','ClientManagementController@ClientCreate');
	Route::get('client-create','ClientManagementController@ClientCreate');
	Route::post('client-store','ClientManagementController@ClientStore');
	Route::post('client-delete','ClientManagementController@clientDelete');

	Route::get('callog-list','CalllogController@callogIndex');
	Route::get('callog-edit/{id}','CalllogController@calllogCreate');
	Route::get('callog-create','CalllogController@calllogCreate');
	Route::post('callog-store','CalllogController@callogStore');
	Route::post('callog-delete','CalllogController@callogDelete');
});
