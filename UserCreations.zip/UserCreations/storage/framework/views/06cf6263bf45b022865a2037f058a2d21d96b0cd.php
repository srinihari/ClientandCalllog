<?php $__env->startSection('title','User Management'); ?>
<?php $__env->startSection('content'); ?>
<div clas="container">
<h1>List of Client</h1>
<div id="notification" style="display: none;">
  <span class="dismiss"><a title="dismiss this notification"></a></span>
</div>
	<div class='row'>

		<div class="col-sm-8 text-right">
				
			<div class="col-md-2">
				<div class="">
					<div class="col-md-10 text-right">
						<a href="<?php echo e(url('/callog-create')); ?>" class="btn btn-success">Create Callog</a>
					</div>	
				</div>	
			</div>	
		<div class="clearfix"></div>
		<br>
		<div class="box">
			<div class="table-responsive">
				<table class="table table-bordered table-striped">
					<thead>
						<tr>
						<th>S.no</th>
						<th>ClientName</th>
						<th>From Date</th>
						<th>To Date</th>
						<th>Call Notes</th>
						<th>Action</th>	
						</tr>
					</thead>
					<tbody>
						<?php $count=$calloglist->firstItem(); ?>
						<?php $__empty_1 = true; $__currentLoopData = $calloglist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($count ++); ?></td>
								<td><?php echo e(isset($value->getClient->client_name) ? $value->getClient->client_name : "---"); ?></td>
								<td><?php echo e(isset($value->from_date) ? $value->from_date : "---"); ?></td>
								<td><?php echo e(isset($value->to_Date) ? $value->to_Date : "---"); ?></td>
								<td><?php echo e(isset($value->call_notes) ? $value->call_notes : "---"); ?></td>

								<td>
							<a href="<?php echo e(url('callog-edit/'.$value->id)); ?>"><button class="btn btn-sm btn-primary disable-on-click">Edit</button></a>
                          	<button  type="button" class="btn btn-sm btn-danger callog-delete" value="<?php echo e($value->id); ?>">Delete</button>
								</td>	
							</tr>	
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr><td colspan="5" align="center">No Records Found<td></tr>
							<?php endif; ?>
					</tbody>
				</table>
		</div>	
		<div class="pull-right">
				<?php echo e($calloglist->appends(Request::all())->links()); ?>

		</div>

</div>
<script src="http://code.jquery.com/jquery-1.8.3.min.js" type="text/javascript"></script>
<script text="text/javascript" src="<?php echo e(asset('js/toastr.js')); ?>" ></script>

 <script type="text/javascript">
 	 <?php if(\Session::has('success')): ?>
  	  toastr.success("success","<?php echo e(Session::get('success')); ?>");
  	<?php endif; ?>
 $(document).ready(function(){
 	$('.callog-delete').on('click',function(){
      if(confirm("Are You Sure You Want to Delete")){
      	var id=this.value;
      	    var token = $("meta[name='csrf-token']").attr("content");
     	$.ajax({
      		url:"<?php echo e(url('/calllog-delete')); ?>",
      		type:"POST",
      		data:{'id':id,'_token':token},
      		success:function(){
      			alert('Delete success');
      			location.reload();
      		}
      	})
      }
    });
 })
 </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>