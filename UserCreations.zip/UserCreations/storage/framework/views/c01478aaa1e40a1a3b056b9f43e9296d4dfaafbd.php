<?php $__env->startSection('title', 'User Creation'); ?>
<?php $__env->startSection('content'); ?> 
<section class="content-header">
  <h1><?php echo $pagetitle; ?></h1>
</section>
<section class="content">
  <div class="box">
    <div class="box-body">
      <?php echo Form::open(array('url' => 'user-create', 'class' => 'form-horizontal', 'method' =>'post', 'id'=>'create_user')); ?>

      <?php echo Form::hidden('id',$user_id); ?>

      <input type='hidden'  name="txt_name" class="txt_name" id="txt_name" value="<?php echo e($user_id); ?>" />
      <div class="form-group">
        <?php echo Form::label('Name',null,array('class' => 'col-md-4 control-label')); ?>

        <div class="col-md-5 fg-float <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
          <?php echo Form::text('name',old( 'name', $users['name'] ),array('class'=>'form-control','id'=> 'js-name','maxlength' => '50')); ?>  
          <span style="color:red" id="js-err-name">
        </div> 
      </div> 
      <div class="form-group">
        <?php echo Form::label('Email Address',null,array('class' => 'col-md-4 control-label')); ?>

        <div class="col-md-5 fg-float <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
          <?php echo Form::text('email',old( 'email', $users['email'] ),array('class'=>'form-control','id'=> 'js-email')); ?>                               
          <span style="color:red" id="js-err-email">
        </div>
      </div>
      <div class="form-group">
       <?php echo Form::label('Mobile Number',null,array('class' => 'col-md-4 control-label')); ?>

       <div class="col-md-5 fg-float <?php echo e($errors->has('mobile_no') ? ' has-error' : ''); ?>">
         <?php echo Form::text('mobile_no',old( 'mobile_no', $users['mobile_no'] ),array('class'=>'form-control','id'=> 'js-mobile_no','maxlength'=>'10')); ?>                               
                   <span id="js-err-mobile" style="color:red"></span>
                                                
       </div>
     </div>
     <?php if(empty($id)): ?>
     <div class="form-group">
      <?php echo Form::label('Password',null,array('class' => 'col-md-4 control-label')); ?> 
      <div class="col-md-5 fg-float<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
        <?php echo Form::password('password',  array('class'=>'form-control','id'=> 'js-password')); ?> 
          <span style="color:red" id="js-err-password">                        
      </div>
    </div>
    <div class="form-group">
     <?php echo Form::label('Confirm password',null,array('class' => 'col-md-4 control-label')); ?> 
     <div class="col-md-5 fg-float<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
      <?php echo Form::password('password_confirmation',  array('class'=>'form-control','id'=> 'js-password_confirmation')); ?> 
          <span style="color:red" id="js-err-pwd-cfm">
    </div>
  </div>
  <?php endif; ?>                  
<br>
<div class="col-md-12 text-center">
  <?php echo Form::button('Submit', array('class'=>'btn btn-primary  waves-effect',  'id'=> 'js-saveusers','type'=>'button')); ?> &nbsp; 
  <a href="<?php echo url('/users'); ?>">  <span  class="btn btn-danger waves-effect">Cancel</span></a>
</div>  
<?php echo Form::close(); ?> 
</div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
 <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
$('#js-saveusers').on('click',function(){
  var name=$('#js-name').val();
  var email=$('#js-email').val();
  var email_pattern=/^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
  var mobile_no=$('#js-mobile_no').val();
  var password=$('#js-password').val();
  var password_confirmation=$('#js-password_confirmation').val();

  if(name == "" || name== null){
    $('#js-err-name').text('Enter the name');
    return false;
  }else if(email == "" || email == null){
    $('#js-err-name').text("");
    $('#js-err-email').text('Enter the Email');
    return false;
  }else if(!email_pattern.test(email)){
    $('#js-err-email').text("");
    $('#js-err-email').text('Enter the Valid Email');
    return false;
  }else if(mobile_no == "" || mobile_no == null){
    $('#js-err-name').text("");
    $('#js-err-email').text("");
    $('#js-err-mobile').text('Enter the Mobile Number');
    return false;
  }else if(password == "" || password == null){
    $('#js-err-name').text("");
    $('#js-err-email').text("");
    $('#js-err-mobile').text("");
    $('#js-err-password').text('Enter the Password');
    return false;
  }else if(password_confirmation == "" || password_confirmation == null){
    $('#js-err-name').text("");
    $('#js-err-email').text("");
    $('#js-err-mobile').text("");
    $('#js-err-password').text("");
    $('#js-err-pwd-cfm').text('Enter the Confirm Password');
    return false;
  }else if(password !=password_confirmation){
        $('#js-err-pwd-cfm').text("Password Don't Match");
        return false;
  }else{
    $('#create_user').submit();
  }

})
})
    
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>