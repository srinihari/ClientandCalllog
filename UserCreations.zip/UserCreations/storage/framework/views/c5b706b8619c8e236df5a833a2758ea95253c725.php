<?php $__env->startSection('title','User Management'); ?>
<?php $__env->startSection('content'); ?>
    <link href="css/toastr.css" rel="stylesheet">

<div clas="container">
<h1>List of Users</h1>
<div id="notification" style="display: none;">
  <span class="dismiss"><a title="dismiss this notification"></a></span>
</div>
	<div class='row'>

		<div class="col-sm-8 text-right">
				
			<div class="col-md-2">
				<div class="">
					<div class="col-md-10 text-right">
						<a href="<?php echo e(url('/user-creation')); ?>" class="btn btn-success">New User</a>
					</div>	
				</div>	
			</div>	
		<div class="clearfix"></div>
		<br>
		<div class="box">
			<div class="table-responsive">
				<table class="table table-bordered table-striped">
					<thead>
						<tr>
						<th>S.no</th>
						<th>Name</th>
						<th>Email</th>
						<th>Mobile Number</th>
						<th>Action</th>	
						</tr>
					</thead>
					<tbody>
						<?php $count=$userlist->firstItem(); ?>
						<?php $__empty_1 = true; $__currentLoopData = $userlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($count ++); ?></td>
								<td><?php echo e(isset($value->name) ? $value->name : "---"); ?></td>
								<td><?php echo e(isset($value->email) ? $value->email : "---"); ?></td>
								<td><?php echo e(isset($value->mobile_no) ? $value->mobile_no : "---"); ?></td>
								<td>
							<a href="<?php echo e(url('user-edit/'.$value->id)); ?>"><button class="btn btn-sm btn-primary disable-on-click">Edit</button></a>
                          	<button  type="button" class="btn btn-sm btn-danger user_delete" value="<?php echo e($value->id); ?>">Delete</button>
								</td>	
							</tr>	
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr><td colspan="5" align="center">No Records Found<td></tr>
							<?php endif; ?>
					</tbody>
				</table>
		</div>	
		<div class="pull-right">
				<?php echo e($userlist->appends(Request::all())->links()); ?>

		</div>

</div>
<?php echo Form::open(array('url'=>'/user-delete/','method'=>'DELETE','id' =>'js-delete-user' )); ?>

<?php echo Form::hidden('id',null,array('id'=>'id')); ?>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
 <script src="/js/jquery.min.js"></script>
 <script src="/js/toastr.js" text="text/javascript"></script>
 <script type="text/javascript">
 $(document).ready(function(){
 	$('.user_delete').on('click',function(){
      if(confirm("Are You Sure You Want to Delete")){
      	var id=this.value;
      	    var token = $("meta[name='csrf-token']").attr("content");
     	$.ajax({
      		url:"<?php echo e(url('/user-delete')); ?>",
      		type:"POST",
      		data:{'id':id,'_token':token},
      		success:function(){
      			alert('Delete success');
      		}
      	})
      }
    });
 })
  
  <?php if(\Session::has('success')): ?>
  	  toastr.success("success","<?php echo e(Session::get('success')); ?>");
  	<?php endif; ?>
  	
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>